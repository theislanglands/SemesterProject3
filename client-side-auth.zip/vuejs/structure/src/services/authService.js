// Login()
// getAccessToken()
// SignOut()

import { JWTHelperFunctions } from "@/helpers/JWTHelper";
import { getCookie } from "@/helpers/CookieHelper";

function authenticate() {
  //refreshAccessToken();
  const jwtAccessToken = JWTHelperFunctions.parseCookie("authcookie");
  return jwtAccessToken;
}

//function refreshAccessToken() {}

// The endpoint of the Connection Security (Team 10) authServer
const authServiceEndpoint = "http://localhost:3300/auth/login";

// Test credentials on the authServer
const name = "Pat";
const password = "hej";

async function login() {
  fetch(authServiceEndpoint, {
    credentials: "include",
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ username: name, password: password }),
  })
    .then((response) => {
      if (response.status == 200) console.log("Successfully logged in");
    })
    .catch((error) => {
      console.log("Sign-in failed: " + error);
    });
}

function getAccessToken() {
  const accessToken = getCookie("authcookie");
  console.log(accessToken);
  return accessToken;
}

function signOut() {
  // Should send refreshCookie ID to database endpoint to be cleared from database
}

export const authService = {
  getAccessToken,
  signOut,
  login,
  authenticate,
};
