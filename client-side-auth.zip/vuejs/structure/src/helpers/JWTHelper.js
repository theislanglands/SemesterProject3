// Import CookieHelper function, parse them to JS objects
import { getCookie } from "@/helpers/CookieHelper";
import jwt from "jsonwebtoken";

const publicKey = `
-----BEGIN PUBLIC KEY-----
MIGeMA0GCSqGSIb3DQEBAQUAA4GMADCBiAKBgGxuskVkUsH8WRW6ul6LQMtvvLU4
wZyJZmcPUONSmr5qxkqBKixfgWz9AjwiKhOPDZV4ZN6mnIZdiB/j9RtSqgGeQWVO
CCs20c9uTYJmORgsPXWpNzLEk9qAWrUBEra1D2EPwkf1ivr6MmCRMIBbGH7oHDzu
yIRG9BsJSMuzNm6XAgMBAAE=
-----END PUBLIC KEY-----
`;

// getCookie returnerer en string?
export const JWTHelperFunctions = {
  parseCookie: function parseCookie(name) {
    const cookie = getCookie(name);
    const token = jwt.verify(cookie, publicKey, { algorithms: "RS256" });
    return token;
  },
};
