export const baseURL = "http://localhost:5000/"
export const playlistURL = baseURL + "playlist/"