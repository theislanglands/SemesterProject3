<template>
  <div id="Playlist">
    <ul id="playlists">
        <li v-for="playlist in playlists" :key="playlist.id">
            <b>{{ playlist.title }}</b> created {{playlist.date}}
        </li>
    </ul>
  </div>
</template>

<script>
import { PlaylistService } from '@/services/PlaylistService'

export default {
  name: 'Playlist',
  data() {
    return {
      playlists: []
    };
  },
  created() {
    this.loadPlaylists();
  },
  methods: {
    async loadPlaylists() {
      try {
        let username = "testuser"; //This should be loaded from the cookie 
        this.playlists = await PlaylistService.getPlaylists(username);
      } catch (error) {
        console.log(error.message);
      }
    }
  }
}
</script>

<style>
</style>