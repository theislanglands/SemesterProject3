# Client-side authentication
